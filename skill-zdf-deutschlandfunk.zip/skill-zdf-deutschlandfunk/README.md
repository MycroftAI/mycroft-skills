## Description:
latest news from http://www.deutschlandfunk.de/podcast-nachrichten.1257.de.podcast.xml from Deutschlandfunk

## Usage:
* `Deutschlandfunk news`
* `news from Deutschlandfunk`
* `Deutschlandfunk`
* `news Deutschlandfunk`
