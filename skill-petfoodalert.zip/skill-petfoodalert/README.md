# PetFoodAlert

## Usage:
* `Can my dog eat ...?`
* `Can dogs eat ...?`

## List:
The list of food a pet is allowed to eat was gathered across many
resources and is not 100% correct. They can serve as a help,
but I suggest doing your own research.

There are for categories:
* Food dogs are allowed to eat -> `YES`
* Food dogs are not allowed to eat -> `NO`
* Food dogs are allowed to eat in moderate quantities -> `Yes, but in moderate amount`
* Food dogs are allowed to eat if prepared correctly -> `Yes, but only if prepared correctly.`
