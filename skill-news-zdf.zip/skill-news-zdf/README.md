## Description:
latest news from https://www.zdf.de/service-und-hilfe/podcast from ZDF

## Usage:
* `zdf news`
* `play zdf`
* `news zdf`
* `news from zdf`
